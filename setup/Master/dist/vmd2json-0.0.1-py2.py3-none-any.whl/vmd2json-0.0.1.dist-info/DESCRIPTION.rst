This uses xmlutils to try and help with HL7 to XML to JSON conversions.


