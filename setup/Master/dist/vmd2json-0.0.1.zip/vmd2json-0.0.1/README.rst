vmd2json
=======================

A very small wrapper that aims to convert vmd files to json.
----

Initial version for testing.

----
Usage:

python vmd2json.py -in somefile.vmd

----

What's New

First pass - let's see if it works with real vmd files
